// =========================================================
// 🔐 PARTIE 1 : CONNEXION & PROTECTION
// =========================================================

const formLogin = document.getElementById("login-form");

if (formLogin) {
    formLogin.addEventListener("submit", function(e) {
        e.preventDefault();

        const email = document.getElementById("email").value.trim();
        const password = document.getElementById("password").value.trim();
        const error = document.getElementById("error-message");

        // Test de connexion simple
        if (email === "user@club.tn" && password === "1234") {
            const user = { email: email };
            localStorage.setItem("user", JSON.stringify(user));
            localStorage.setItem("isLoggedIn", "true");
            window.location.href = "home.html";
        } else {
            error.textContent = "Email ou mot de passe incorrect";
            error.style.display = "block";
        }
    });
}

// Vérification de sécurité sur chaque page
const isLoggedIn = localStorage.getItem("isLoggedIn");
const currentPage = window.location.pathname.split("/").pop();

// Liste des pages accessibles sans être connecté
const publicPages = ["index.html", ""]; 

if (!publicPages.includes(currentPage) && isLoggedIn !== "true") {
    window.location.href = "index.html";
}

// =========================================================
// 📅 PARTIE 2 : GESTION DES ÉVÉNEMENTS (Affichage)
// =========================================================

const evenements = [
    { id: 1, titre: "Soirée Gnawa", date: "15 mars 2026", lieu: "Tunis", image: "images/event1.jpg", description: "Plongez au cœur d'une soirée électrique où la passion du Blues rencontre l'énergie brute du Rock. Un concert intimiste porté par une voix puissante et des riffs de guitare envoûtants, pour une expérience musicale authentique et vibrante.", places: "45" },
    { id: 2, titre: "Harmonies Classiques", date: "20 mars 2026", lieu: "Sousse", image: "images/event2.jpg", description: "Laissez-vous transporter par la finesse des violons et la profondeur des violoncelles. Ce concert classique réunit des musiciens talentueux pour interpréter les plus grands chefs-d'œuvre du répertoire symphonique dans une ambiance acoustique exceptionnelle..", places: "30" },
    { id: 3, titre: "Gala de Ballet Classique", date: "25 mars 2026", lieu: "Sfax", image: "images/event3.jpg", description: "Une célébration de la grâce et de la précision technique. Ce spectacle de ballet classique vous invite à découvrir la magie de la danse à travers des chorégraphies élégantes et des costumes somptueux, offrant un voyage poétique hors du temps.", places: "100" }
];

const grid = document.querySelector(".grid-evenements");
if (grid) {
    grid.innerHTML = "";
    evenements.forEach(ev => {
        grid.innerHTML += `
            <article class="card-event">
                <img src="${ev.image}" alt="${ev.titre}">
                <h3>${ev.titre}</h3>
                <p>Date : ${ev.date}</p>
                <a href="event-details.html?id=${ev.id}" class="btn">Voir détails</a>
            </article>
        `;
    });
}

// Détails de l'événement
const params = new URLSearchParams(window.location.search);
const eventId = parseInt(params.get("id"));

if (eventId && document.getElementById("event-titre")) {
    const ev = evenements.find(item => item.id === eventId);
    if (ev) {
        document.getElementById("event-titre").textContent = ev.titre;
        document.getElementById("event-image").src = ev.image;
        document.getElementById("event-description").textContent = ev.description;
        document.getElementById("inscription-link").href = "register-event.html?id=" + ev.id;
    }
}

// =========================================================
// 📝 PARTIE 3 : FORMULAIRE D'INSCRIPTION (TP 9)
// =========================================================

const formRegister = document.getElementById("register-form");

if (formRegister) {
    formRegister.addEventListener("submit", function(e) {
        e.preventDefault();

        // Récupérer les valeurs
        const nom = document.getElementById("nom").value.trim();
        const email = document.getElementById("email").value.trim();
        const telephone = document.getElementById("telephone").value.trim();
        const places = document.getElementById("places").value;
        const message = document.getElementById("message").value.trim();

        const errorDiv = document.getElementById("error-message");
        const successDiv = document.getElementById("success-message");

        // Récupérer le nom de l'événement via l'ID dans l'URL
        const currentEvent = evenements.find(ev => ev.id === eventId);
        const eventTitre = currentEvent ? currentEvent.titre : "Événement";

        // Validation (Contrôle de saisie)
        if (nom.length < 3) {
            return showMsg(errorDiv, "Le nom doit avoir au moins 3 caractères");
        }
        if (!email.includes("@")) {
            return showMsg(errorDiv, "Email invalide");
        }
        if (!/^\d{8}$/.test(telephone)) {
            return showMsg(errorDiv, "Le téléphone doit contenir 8 chiffres");
        }

        // Créer l'objet inscription
        const nouvelleInscription = {
            eventTitre: eventTitre,
            nom: nom,
            email: email,
            telephone: telephone,
            places: places,
            message: message
        };

        // Sauvegarder dans le tableau localStorage
        let inscriptions = JSON.parse(localStorage.getItem("inscriptions")) || [];
        inscriptions.push(nouvelleInscription);
        localStorage.setItem("inscriptions", JSON.stringify(inscriptions));

        // Succès et Redirection
        errorDiv.style.display = "none";
        showMsg(successDiv, "Inscription réussie ! Redirection...");
        
        setTimeout(() => {
            window.location.href = "profile.html";
        }, 2000);
    });
}

function showMsg(div, msg) {
    div.innerText = msg;
    div.style.display = "block";
}

// =========================================================
// 👤 PARTIE 4 : AFFICHAGE PROFIL (Ta partie corrigée)
// =========================================================

window.addEventListener("load", function() {
    const list = document.getElementById("inscriptions-list");
    const emailSpan = document.getElementById("user-email");

    // 1. Email de l'utilisateur
    const userData = JSON.parse(localStorage.getItem("user"));
    if (emailSpan && userData) {
        emailSpan.textContent = userData.email;
    }

    // 2. Liste des inscriptions
    if (list) {
        const inscriptions = JSON.parse(localStorage.getItem("inscriptions")) || [];

        if (inscriptions.length === 0) {
            list.innerHTML = "<p>Aucune inscription trouvée.</p>";
        } else {
            list.innerHTML = "";
            inscriptions.forEach((ins) => {
                list.innerHTML += `
                    <div class="card-event" style="width: 100%; max-width: 500px; margin: 10px auto; height: auto;">
                        <h3>${ins.eventTitre}</h3>
                        <p><strong>Nom :</strong> ${ins.nom}</p>
                        <p><strong>Places :</strong> ${ins.places}</p>
                        <p><strong>📞 :</strong> ${ins.telephone}</p>
                    </div>
                `;
            });
        }
    }
});

// =========================================================
// 🚪 PARTIE 5 : DÉCONNEXION
// =========================================================

function logout() {
    localStorage.removeItem("user");
    localStorage.removeItem("isLoggedIn");
    window.location.href = "index.html";
}